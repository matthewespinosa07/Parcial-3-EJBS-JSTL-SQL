package ejbs;

//import java.sql.Date;
import java.util.Date;

import jakarta.ejb.Remote;

@Remote
public interface LibroRemote {
	// imprime toda la información del libro
	void setLibro(int id, String titulo, String autor, int paginas, String editorial, int anio_publicacion, String genero, Date fecha_prestamo, Date fecha_entrega);
	// lógica de negocios
	int tiempoPrestamo();
	double timepoLectura();
}
