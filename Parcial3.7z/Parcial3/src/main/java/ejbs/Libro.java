package ejbs;

import java.util.Date;

import jakarta.ejb.LocalBean;
import jakarta.ejb.Stateless;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * Session Bean implementation class Libro
 */
@Stateless
@LocalBean
public class Libro implements LibroRemote {

	public int id;
	public String titulo;
	public String autor;
	public int paginas;
	public String editorial;
	public int anio_publicacion;
	public String genero;
	public Date fecha_prestamo;
	public Date fecha_entrega;

	/**
	 * Default constructor.
	 */
	public Libro() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void setLibro(int id, String titulo, String autor, int paginas, String editorial, int anio_publicacion,
			String genero, Date fecha_prestamo, Date fecha_entrega) {
		this.id = id;
		this.titulo = titulo;
		this.autor = autor;
		this.paginas = paginas;
		this.editorial = editorial;
		this.anio_publicacion = anio_publicacion;
		this.genero = genero;
		this.fecha_prestamo = fecha_prestamo;
		this.fecha_entrega = fecha_entrega;
	}

	@Override
	public int tiempoPrestamo() {
		// TODO Auto-generated method stub
		long diffInMillies = Math.abs(fecha_entrega.getTime() - fecha_prestamo.getTime());
		long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
		return (int) diff;
	}

	@Override
	public double timepoLectura() {
		// TODO Auto-generated method stub
		return paginas * 4.0;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public int getPaginas() {
		return paginas;
	}

	public void setPaginas(int paginas) {
		this.paginas = paginas;
	}

	public String getEditorial() {
		return editorial;
	}

	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}

	public int getAnio_publicacion() {
		return anio_publicacion;
	}

	public void setAnio_publicacion(int anio_publicacion) {
		this.anio_publicacion = anio_publicacion;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public Date getFecha_prestamo() {
		return fecha_prestamo;
	}

	public void setFecha_prestamo(Date fecha_prestamo) {
		this.fecha_prestamo = fecha_prestamo;
	}

	public Date getFecha_entrega() {
		return fecha_entrega;
	}

	public void setFecha_entrega(Date fecha_entrega) {
		this.fecha_entrega = fecha_entrega;
	}

}
